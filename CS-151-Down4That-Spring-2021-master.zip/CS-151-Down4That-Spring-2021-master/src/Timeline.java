/**
 * This class is meant to keep the timeline GUI component updated all the time
 * while it is running on the website.
 * 
 * @deprecated Legacy code when attempting to set up web app implemenation with
 *             browser-based GUI. May be updated to be better suited for a local
 *             java swing GUI implementation.
 * 
 * @author Akela Do-Ho
 */
public class Timeline {

    public void init() {
        // we'll figure this out
    }

    /**
     * This will allow all the events on eventList to be displayed onto the
     * timeline.
     */
    public void displayEvents(EventList eventsToDisplay) {
        // we'll work this together
    }

    /**
     * This will get the specific getEventlists
     */
    public void getEventList() {
        // Dylan had an idea for this one, don't specifically remember our intentions
        // behind this one.
    }
}